=== Featured Image In RSS Feed ===
Contributors: dnesscarkey
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=NX89F5F93YTZJ
Tags: featured image, rss, feed, image in rss feed
Requires at least: 3.0.
Tested up to: 3.7.1
Stable tag: 1.0
License: GPLv2

This plugin adds featured image to your rss feed

== Description ==

This Plugin adds featured image to your rss feed.

You can changes the image size from the setting page of the plugin under Settings > Image In RSS Feed. By default the plugin uses thumbnail size.

Note: We don't monitor support request posted here. For any issues please visit our <a href="http://dineshkarki.com.np/forums/forum/featured-image-in-rss" target="_blank">support forum</a>. 

Thanks to <a href="http://wework4web.com" target="_blank">wework4web</a> for supporting plugin developement.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Change the image size from the setting page of the plugin under settings > Image In RSS Feed (If Required).

== Frequently Asked Questions ==

= Can i change the image size ? =

Yes, you can change the image size from the settings page of the plugin.

== Changelog ==

= 1.0 =
* 3.7.1 Tested
* Now supports custom image sizes.

= 0.2 =
* Fix Large Image Issue
* Added Full Size Image

= 0.1 =
* First Release