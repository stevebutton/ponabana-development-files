<?php $layout = 3; get_header(); ?>

<?php get_template_part('wrapper', 'start'); ?>

	<?php get_template_part('content', 'none'); ?>

<?php get_template_part('wrapper', 'end'); ?>

<?php get_footer(); ?>